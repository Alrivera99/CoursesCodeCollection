import { Injectable } from '@nestjs/common';

@Injectable()
export class CarsService {
  private cars = [
    {
      id: 1,
      name: 'Ford',
    },
    {
      id: 2,
      name: 'Toyota',
    },
    {
      id: 3,
      name: 'Honda',
    },
  ];

  findAll() {
    return this.cars;
  }

  findOne(id: string) {
    return this.cars[Number(id)];
  }
}
