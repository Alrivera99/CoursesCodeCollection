import { Controller, Get, Param } from '@nestjs/common';
import { CarsService } from './cars.service';

@Controller({ path: 'cars', version: '1' })
export class CarsController {
  constructor(private readonly CarsService: CarsService) {}
  @Get()
  getAllCars() {
    return this.CarsService.findAll();
  }

  @Get(':id')
  getCarById(@Param('id') id: string) {
    return this.CarsService.findOne(id);
  }
}
